rm(list = ls())
setwd("E:/Yao/Yao-Data20211230")
library(data.table)
library(stringr)
files.name.csv <- list.files(pattern = "*.csv")
files.name <- str_sub(files.name.csv,1,-5)
m <- length(files.name.csv)

lambda.rho <- matrix(NA,m,2)
colnames(lambda.rho) <- c("lambda","rho")
rownames(lambda.rho) <- files.name

point <- matrix(NA,m,2)
point[1,] <- c(0.0012,0.00001)
point[2,] <- c(0.00107496,0.0151497)
point[3,] <- c(0.000867514,0.0188209)
point[4,] <- c(0.00298719,0.0234481)


axis.lambda <- matrix(NA,m,2)
axis.rho    <- matrix(NA,m,2)
axis.lambda[1,] <- c(0,0.3)
axis.lambda[2,] <- c(0.1,0.3)
axis.lambda[3,] <- c(0,0.25)
axis.lambda[4,] <- c(0,0.15)
axis.rho[1,] <- c(0,0.3)
axis.rho[2,] <- c(0.1,0.35)
axis.rho[3,] <- c(0,0.25)
axis.rho[4,] <- c(0,0.2)
# P.CI <- matrix(NA,m,2)
# colnames(P.CI) <- c("P.CI.lower","P.CI.upper")
# rownames(P.CI) <- files.name.csv


for (i in 1:m) {
  setwd("E:/Yao/Yao-Data20211230")
  YaoData <- data.frame(fread(files.name.csv[i],head=T))
  MidT <- YaoData$MidAge
  Rate <- YaoData$Rate
  N <- YaoData$N
  n <- YaoData$n
  
  #========== matrix formla
  P.zero.one <- function(x){
    y <- x[1]*(1-exp(-x[2]*MidT))
    return(y)
  } #由A=x1和r=x2,t计算出一次实验阳性概率
  
  LikeliFun <- function(x){
    choose(N, n)*(P.zero.one(x)^n)*(1-P.zero.one(x))^(N-n)
    } #似然函数
  
  LikeliFun.Log <- function(x){
    -sum(n*log(P.zero.one(x))+(N-n)*log(1-P.zero.one(x)))#log(choose(N, n))+
  } #对数似然函数，这里取相反数，便于optim()函数取最小值，相当于对数似然函数取最大值
    #{-sum(log(LikeliFun(x)))}  #似然函数的另一种形式，容易溢出
  
  P.zero.one.df <- function(x){
    c(P.zero.one.df.A=1-exp(-x[2]*MidT),
      P.zero.one.df.r=x[1]*MidT*exp(-x[2]*MidT))
  } #P.zero.one(x)的导数，输出为向量
  
  LikeliFun.Log.df <- function(x){
    f1 <- -sum(n)/x[1]+sum((N-n)/(1-P.zero.one(x))*(1-exp(-x[2]*MidT)));
    f2 <- -sum(n/(1-exp(-x[2]*MidT))*MidT*exp(-x[2]*MidT))+sum((N-n)/(1-P.zero.one(x))*x[1]*MidT*exp(-x[2]*MidT));
    return(c(f1,f2))
  } #LikeliFun.Log(x)的导数
  
  solve.likeli <- optim(par    = point[i,],      #迭代初始点
                        fn     = LikeliFun.Log,    #取最小值的目标函数
                        gr     = LikeliFun.Log.df, #梯度函数
                        method = "L-BFGS-B",
                        lower  = c(0,0),            #变量的下界
                        #upper  = c(1,1),
                        control = list(maxit=50000)
  ) 
  A <- solve.likeli$par[1]
  r <- solve.likeli$par[2]
  lambda <- A*r
  rho <- r*(1-A)
  lambda.rho[i,] <- c(lambda,rho)
  
  
  #### 置信区间
  delta <- 1e-4
  
  P.zero.one.lambda <- function(x){x/(x+rho)*(1-exp(-(x+rho)*MidT))}
  P.zero.one.rho <- function(x){lambda/(lambda+x)*(1-exp(-(lambda+x)*MidT))}
  
  LikeliFun.Log.lambda <- function(x){
    -sum(log(choose(N, n))+n*log(P.zero.one.lambda(x))+(N-n)*log(1-P.zero.one.lambda(x)))
  }
  
  LikeliFun.Log.rho <- function(x){
    -sum(log(choose(N, n))+n*log(P.zero.one.rho(x))+(N-n)*log(1-P.zero.one.rho(x)))
  }
  
  I <- -(LikeliFun.Log.lambda(lambda-delta) - 2*LikeliFun.Log.lambda(lambda) 
         + LikeliFun.Log.lambda(lambda+delta))/(delta^2) #Fhiser 矩阵
  I.rho <- -(LikeliFun.Log.rho(rho-delta) - 2*LikeliFun.Log.rho(rho) 
         + LikeliFun.Log.rho(rho+delta))/(delta^2) #Fhiser 矩阵
  
  sd.lambda <- sqrt(-1/I) #标准差
  sd.rho <- sqrt(-1/I.rho) #标准差
  
  lambda.CI.lower <- lambda - 1.96*sd.lambda
  lambda.CI.upper <- lambda + 1.96*sd.lambda
  
  rho.CI.lower <- rho - 1.96*sd.rho
  rho.CI.upper <- rho + 1.96*sd.rho
  
  P.CI.lower <- P.zero.one.lambda(lambda.CI.lower)
  P.CI.upper <- P.zero.one.lambda(lambda.CI.upper)
  
  P.CI.lower.rho <- P.zero.one.rho(rho.CI.lower)
  P.CI.upper.rho <- P.zero.one.rho(rho.CI.upper)
  
  setwd("E:/Yao/lambda-rho")
  pdf.file.name <- paste(files.name[i], ".lambda.pdf", sep="")
  pdf(file=pdf.file.name)
  
  textleg<-paste("lambda=",round(lambda,4),"(",round(lambda.CI.lower,4),",",round(lambda.CI.upper,4),")")
  
  plot(MidT,P.zero.one(c(A,r)),type = "l",lwd=3,ylim=axis.lambda[i,],xlim=c(8,65),xlab = "Age", ylab = "Positive probability")
  points(MidT, Rate, pch=2)
  legend(x=8,y=axis.lambda[i,2],legend=textleg, bty ="n", pch=NA)
  lines(MidT,P.CI.lower,col="blue",lty=2,lwd=3)
  lines(MidT,P.CI.upper,col="blue",lty=2,lwd=3)
  title(main=files.name[i])
  dev.off()

  
  pdf.file.name <- paste(files.name[i], ".rho.pdf", sep="")
  pdf(file=pdf.file.name)
  
  textleg<-paste("rho=",round(rho,4),"(",round(rho.CI.lower,4),",",round(rho.CI.upper,4),")")
  
  plot(MidT,P.zero.one(c(A,r)),type = "l",lwd=3,ylim=axis.rho[i,],xlim=c(8,65),xlab = "Age", ylab = "Positive probability")
  points(MidT, Rate, pch=2)
  legend(x=8,y=axis.rho[i,2],legend=textleg, bty ="n", pch=NA)
  lines(MidT,P.CI.lower.rho,col="blue",lty=2,lwd=3)
  lines(MidT,P.CI.upper.rho,col="blue",lty=2,lwd=3)
  title(main=files.name[i])
  dev.off()  
}

#====== 输出结果
lambda.rho <- as.data.frame(lambda.rho)
setwd("E:/Yao/lambda-rho")
fwrite(lambda.rho,"lambda_rho.txt",sep = "\t",quote = F,append=F,col.names=T,row.names=T)







curve(A*(1-exp(-r*x)),from=0,to=70,add=TRUE,col="yellow",lty=2,lwd=2)

curve(lambda.CI.lower/(lambda.CI.lower+rho)*(1-exp(-(lambda.CI.lower+rho)*x)),from=0,to=70,add=TRUE,col="red",lty=2,lwd=2)

curve(lambda.CI.upper/(lambda.CI.upper+rho)*(1-exp(-(lambda.CI.upper+rho)*x)),from=0,to=70,add=TRUE,col="blue",lty=2,lwd=2)
